
// Excercise 2

public class LinkedStack<I> extends Stack<I> {


	public LinkedStack() {
		stackItems = new LinkedList<I>();
	}

	


}
